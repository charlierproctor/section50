<?php

    // funtion to print "hello, $name"
    function hello($name) {
        return "hello, " . $name . "!";
    }
    
    // prints hello, section
    echo hello("section");
?>
