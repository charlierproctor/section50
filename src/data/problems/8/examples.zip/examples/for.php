<?php
    $res = 0;
    for ($i = 0; $i < 10; $i++) {
        $res += $i;
    }
    
    // prints 45
    echo $res;
?>