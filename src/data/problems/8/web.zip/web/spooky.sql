-- RUN THIS SQL CODE IN PHPMYADMIN TO SETUP THE DATABASE FOR OUR SPOOKY WEBSITE

--
-- Database: `spooky_videos`
--

CREATE DATABASE IF NOT EXISTS `spooky_videos`;
USE `spooky_videos`;

-- --------------------------------------------------------

--
-- Table structure for table `spooky_table`
--

CREATE TABLE IF NOT EXISTS `spooky_table` (
  `primary_key` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB;

