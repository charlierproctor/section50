<!DOCTYPE html>
<html>
<head>
    <title>Halloween</title>
</head>    
<body>
    <form method="get" action="spooky.php">
        <input type="text" name="video" placeholder="spooky video"/>
        <input type="submit" value="Submit"/>
    </form>
</body>
</html>