<!DOCTYPE html>
<?php
    // display errors, warnings, and notices
    ini_set("display_errors", true);
    error_reporting(E_ALL);
    
    // CS50 Library
    require("vendor/library50-php-5/CS50/CS50.php");
    CS50::init(__DIR__ . "/config.json");
    
    // insert this new video into the spooky_table
    if ($_GET["video"]) {
        CS50::query("INSERT INTO spooky_table (url) VALUES (?)",$_GET["video"]);
    }
?>
<html>
    <head>
        <title>Spooky Video Page</title>
    </head>
    <body>
        <?php
            // get all the rows from the spooky_table
            $rows = CS50::query("SELECT * FROM spooky_table");
            
            // and display the videos
            foreach ($rows as $row) {
                echo '<iframe width="420" height="315" src="' . $row["url"] . '" frameborder="0" allowfullscreen></iframe>';
            }
        ?>
    </body>
</html>