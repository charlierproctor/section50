// a simple variable
var age = 26;

// string
var str = "Happy 4th 21st birthday Gabe!";

// an array
var arr = [1, 2, 3, 4, 5];
arr[0] = 0
arr.push(6)

// an object
var teacher = {name: "Rob", year: 1960};
teacher["name"] = "Charlie"
teacher.year = 2017
