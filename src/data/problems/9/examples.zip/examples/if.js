function bool(val) {
    if (val) {
        console.log("true")
    } else {
        console.log("false")
    }
}

bool(false)
bool(true)

console.log("**********")

bool(0)
bool(2)

console.log("**********")

bool("")
bool("cs50")
