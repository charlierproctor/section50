var num = 5;

while(num) {
    console.log(num);
    num--;
}